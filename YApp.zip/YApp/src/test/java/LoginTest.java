package test; // IMPORTANT: This must match the package name in your NetBeans Test Packages folder

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

// If your Login class is in a different package, you need to import it here:
// import yourprojectname.Login; 

public class LoginTest {

    private Login login;

    @BeforeEach
    public void setUp() {
        // Ensuring the name matches the welcome message expectations
        login = new Login("John", "Doe");
    }

    @Test
    public void testRegisterUser_Success() {
        // Username: 5 chars (Success), Password: 10 chars, 1 Cap, 1 Num, 1 Special (Success)
        String result = login.registerUser("kyl_1", "Ch@r123456", "+27123456789");
        assertEquals("User has successfully registered on YApp!", result);
    }

    @Test
    public void testRegisterUser_UsernameTooLong() {
        // Username is 6 chars, should return the formatting error message
        String result = login.registerUser("johnny", "Ch@r123456", "+27123456789");
        assertEquals("Username is incorrectly formatted. Must be max 5 characters.", result);
    }

    @Test
    public void testRegisterUser_PasswordInvalid() {
        // Password "Password123" is missing a special character
        String result = login.registerUser("kyl_1", "Password123", "+27123456789");
        assertTrue(result.contains("Password is incorrectly formatted"), "Should return password format error");
    }

    @Test
    public void testLoginUser_Success() {
        // Must register first to set the 'username' and 'password' fields in the object
        login.registerUser("kyl_1", "Ch@r123456", "+27123456789");
        
        boolean loginSuccess = login.loginUser("kyl_1", "Ch@r123456");
        assertTrue(loginSuccess, "Login should be successful with correct credentials");
    }

    @Test
    public void testLoginUser_Failure() {
        login.registerUser("kyl_1", "Ch@r123456", "+27123456789");
        
        boolean loginSuccess = login.loginUser("kyl_1", "WrongPass123!");
        assertFalse(loginSuccess, "Login should fail with incorrect password");
    }

    @Test
    public void testReturnLoginStatus_Success() {
        // Testing the string builder logic
        String message = login.returnLoginStatus(true);
        assertEquals("Welcome John Doe, it is great to see you again on YApp!", message);
    }
}