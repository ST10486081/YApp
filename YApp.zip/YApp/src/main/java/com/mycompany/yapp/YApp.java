/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.yapp;

/**
 *
 * @author Student
 */

import java.util.Scanner;

public class YApp {
    public static void main(String[] args) {
       
        // Create a scanner to read user input
        Scanner scanner = new Scanner(System.in);
       
        System.out.println("YApp REGISTRATION SYSTEM");
       
        // Ask for and store the user's name
        System.out.print("Enter your first name: ");
        String firstName = scanner.nextLine();
       
        System.out.print("Enter your last name: ");
        String lastName = scanner.nextLine();
       
        // Create a new Login object using the user's name
        Login userLogin = new Login(firstName, lastName);
       
        System.out.println("\n--- YApp REGISTRATION ---");
       
        // Collect the user's registration details
        System.out.print("Create username (max 5 characters): ");
        String username = scanner.nextLine();
       
        System.out.print("Create password (10-14 chars, 1 capital, 1 number, 1 special char): ");
        String password = scanner.nextLine();
       
        System.out.print("Enter cell phone number (format: +27XXXXXXXXX): ");
        String cellNumber = scanner.nextLine();
       
        // Run the registration logic and display the result
        String registrationResult = userLogin.registerUser(username, password, cellNumber);
        System.out.println("\n" + registrationResult);
       
        // Proceed to login only if registration was successful
        // Note: Check for the actual success message returned by registerUser
        if (registrationResult.contains("successfully registered")) {
            System.out.println("\n=== YApp LOGIN ===\n");
           
            System.out.print("Enter username: ");
            String loginUsername = scanner.nextLine();
           
            System.out.print("Enter password: ");
            String loginPassword = scanner.nextLine();
           
            // Check if the entered details match the registered details
            boolean loginSuccess = userLogin.loginUser(loginUsername, loginPassword);
           
            // Get the appropriate welcome or error message and print it
            String loginMessage = userLogin.returnLoginStatus(loginSuccess);
            System.out.println(loginMessage);
        }
       
        scanner.close();
    }
}

class Login {
    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private String cellNumber;
   
    public Login(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }
   
    public String registerUser(String username, String password, String cellNumber) {
        // Validate username length
        if (username.length() > 5) {
            return "Username is incorrectly formatted. Must be max 5 characters.";
        }
       
        // Validate password complexity
        if (!isValidPassword(password)) {
            return "Password is incorrectly formatted. Must be 10-14 characters long, contain 1 capital letter, 1 number, and 1 special character.";
        }
       
        // Validate phone number format and implement a regex matcher
        if (!cellNumber.matches("\\+27\\d{9}")) {
            return "Cell number is incorrectly formatted. Must be in format: +27XXXXXXXXX";
        }

        // Only save details if validation passes
        this.username = username;
        this.password = password;
        this.cellNumber = cellNumber;
       
        return "User has successfully registered on YApp!";
    }
   
    private boolean isValidPassword(String password) {
        if (password.length() < 10 || password.length() > 14) {
            return false;
        }
       
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
       
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasCapital = true;
            else if (Character.isDigit(c)) hasNumber = true;
            else if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }
       
        return hasCapital && hasNumber && hasSpecial;
    }
   
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return this.username != null &&
               this.username.equals(enteredUsername) &&
               this.password != null &&
               this.password.equals(enteredPassword);
    }
   
    public String returnLoginStatus(boolean loginSuccess) {
        if (loginSuccess) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again on YApp!";
        } else {
            return "Username or password incorrect, please try again to successfully login on YApp.";
        }
    }
}